# TheBattleCatsMod

Version History:
1.0 - Initial release, introducing cat, cat-on-a-duo and cat-food-generator that generates cat-food
1.011 - updated description and sprites, nerfed cat-on-a-duo. 
1.02 - updated the script to hjson format
1.1 - introducing, cat-unit and cat-unit-factory. 
1.2 - change cat-on-a-duo into duo-with-cat, complete overhaul. Hid cat-unit due to still work in progress. 
