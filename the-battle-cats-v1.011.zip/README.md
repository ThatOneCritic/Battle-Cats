# TheBattleCatsMod

Version History:
1.0 - Initial release, introducing cat, cat-on-a-duo and cat-food-generator that generates cat-food
1.011 - updated description and sprites, nerfed cat-on-a-duo. 
